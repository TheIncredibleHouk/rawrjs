﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface IDocument
    {
        byte[] Data { get; set; }
        string ID { get; set; }
        string MimeType { get; set; }
        int Order { get; set; }
        string Name { get; set; }
    }
}
