﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface IRecipient
    {
         string AccessCode { get; set; }
         string DeclineReason { get; set; }
         DateTime DeliveredOn { get; set; }
         string Email { get; set; }
         string ID { get; set; }
         string IDCheckConfigurationName { get; set; }
         bool InheritEmailNotificationConfiguration { get; set; }
         string Name { get; set; }
         bool RequireIDLookup { get; set; }
         string RoleName { get; set; }
         int RoutingOrder { get; set; }
         DateTime SignedOn { get; set; }
         EnvelopeStatus Status { get; set; }
    }
}
