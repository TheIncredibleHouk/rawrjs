﻿using SAI.STP.DocuSignIntegration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface IRecipientInfo
    {
         IEnumerable<IRecipient> CarbonCopies { get; set; }
         int Count { get; }
         IEnumerable<ISigner> Signers { get; set; }

         bool Any(Func<IRecipient, bool> predicate);
         IRecipient FirstOrDefault(Func<IRecipient, bool> predicate);
    }
}
