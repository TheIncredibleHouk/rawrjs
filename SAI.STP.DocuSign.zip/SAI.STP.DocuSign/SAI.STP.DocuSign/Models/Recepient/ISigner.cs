﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface ISigner : IRecipient
    {
         ISignatureInfo SignatureInfo { get; set; }
         ITabCollection Tabs { get; set; }
    }
}
