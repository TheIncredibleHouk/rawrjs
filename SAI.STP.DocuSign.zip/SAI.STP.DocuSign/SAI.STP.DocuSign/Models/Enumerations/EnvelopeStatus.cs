﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public enum EnvelopeStatus
    {
        Unknown = 0,
        Voided = 1,
        Created = 2,
        Deleted = 3,
        Sent = 4,
        Delivered = 5,
        Signed = 6,
        Completed = 7,
        Declined = 8,
        TimedOut = 9,
        AutoResponded = 10,
    }
}
