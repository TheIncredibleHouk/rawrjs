﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public enum FontStyle
    {
        RageItalic = 0,
        Mistral = 1,
        BradleyHandITC = 2,
        KaufmannBT = 3,
        Freehand575 = 4,
        LuciaBT = 5,
        DocuSign1 = 6,
        DocuSign2 = 7,
        DocuSign3 = 8,
        DocuSign4 = 9,
        DocuSign5 = 10,
        DocuSign6 = 11,
        DocuSign7 = 12,
        DocuSign8 = 13,
    }
}
