﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface IAuthenticationTokenResponse
    {
        string Access_Token { get; set; }
        string Scope { get; set; }
        string Token_Type { get; set; }
        string BaseURL { get; set; }
        string AccountID { get; set; }
    }
}
