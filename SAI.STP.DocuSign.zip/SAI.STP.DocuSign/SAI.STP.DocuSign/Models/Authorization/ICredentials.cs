﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface ICredentials
    {
         string Key { get; set; }
         string LoginID { get; set; }
         string LoginPassword { get; set; }
         string SendOnBehalf { get; set; }
    }
}
