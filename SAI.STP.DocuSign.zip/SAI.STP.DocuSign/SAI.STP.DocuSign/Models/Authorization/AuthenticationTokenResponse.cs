﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public class AuthenticationTokenResponse: IAuthenticationTokenResponse
    {
        public string Access_Token { get; set; }
        public string Scope { get; set; }
        public string Token_Type { get; set; }
        public string BaseURL { get; set; }
        public string AccountID { get; set; }
    }
}
