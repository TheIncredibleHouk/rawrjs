﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface ITab
    {
         string DocumentID { get; set; }
         string PageNumber { get; set; }
       string RecipientID { get; set; }
         string XPosition { get; set; }
         string YPosition { get; set; }
    }
}
