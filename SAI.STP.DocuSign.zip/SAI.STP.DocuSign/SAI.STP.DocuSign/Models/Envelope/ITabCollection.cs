﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface ITabCollection
    {
         IEnumerable<ITab> DateSignedTabs { get; set; }
         IEnumerable<ITab> InitialHereTabs { get; set; }
         IEnumerable<ITab> SignHereTabs { get; set; }
    }
}
