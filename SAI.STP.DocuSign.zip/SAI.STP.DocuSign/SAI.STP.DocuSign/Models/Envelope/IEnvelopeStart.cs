﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface IEnvelopeStart
    {
         IEnumerable<IDocument> Documents { get; set; }
         string EmailBody { get; set; }
         string EmailSubject { get; set; }
         IRecipientInfo Recipients { get; set; }
         EnvelopeStatus Status { get; set; }
    }
}
