﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public interface IEnvelopeCondition
    {
        string Status { get; set; }
        string ID { get; set; }
        string Date { get; set; }
        string Uri { get; set; }
    }
}
