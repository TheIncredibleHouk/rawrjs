﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAI.STP.DocuSignIntegration
{
    public class EnvelopeCondition : IEnvelopeCondition
    {

        public string Status { get; set; }

        public string ID { get; set; }

        public string Date { get; set; }

        public string Uri { get; set; }
    }
}
