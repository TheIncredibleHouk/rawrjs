﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SAI.STP.DocuSignIntegration
{
    public class ConnectRecipient
    {
        public ConnectRecipient()
        {
            SentOn = new DateTime(1900, 01, 01);
            DeliveredOn = new DateTime(1900, 01, 01);
            SignedOn = new DateTime(1900, 01, 01);
        }

        [XmlElement("RoutingOrder")]
        public int RoutingOrder { get; set; }

        [XmlElement("Email")]
        public string Email { get; set; }

        [XmlElement("UserName")]
        public string Name { get; set; }

        [XmlElement("Type")]
        public string Type { get; set; }

        [XmlElement("Sent")]
        public DateTime SentOn { get; set; }

        [XmlElement("Delivered")]
        public DateTime DeliveredOn { get; set; }

        [XmlElement("Signed")]
        public DateTime SignedOn { get; set; }

        [XmlElement("DeclineReason")]
        public string DeclineReason { get; set; }

        [XmlElement("Status")]
        public EnvelopeStatus Status { get; set; }
    }
}
