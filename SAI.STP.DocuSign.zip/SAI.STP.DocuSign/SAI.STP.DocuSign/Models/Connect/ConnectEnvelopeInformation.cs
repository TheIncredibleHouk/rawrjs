﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SAI.STP.DocuSignIntegration
{
    public class ConnectEnvelopeInformation
    {
        [XmlElement("EnvelopeStatus")]
        public ConnectEnvelope Envelope { get; set; }
    }
}
