﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SAI.STP.DocuSignIntegration
{
    public class ConnectCustomField
    {
        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("Show")]
        public bool Show { get; set; }

        [XmlElement("Required")]
        public bool Required { get; set; }

        [XmlElement("Value")]
        public string Value { get; set; }
        
    }
}
