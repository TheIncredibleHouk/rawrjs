﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace SAI.STP.DocuSignIntegration
{
    public class ConnectEnvelope
    {
        public ConnectEnvelope()
        {
            LastUpdated = new DateTime(1900, 01, 01);
            CreatedOn = new DateTime(1900, 01, 01);
            SentOn = new DateTime(1900, 01, 01);
            DeliveredOn = new DateTime(1900, 01, 01);
            SignedOn = new DateTime(1900, 01, 01);
            CompletedOn = new DateTime(1900, 01, 01);
        }

        [XmlElement("TimeGenerated")]
        public DateTime LastUpdated { get; set; }

        [XmlArray("RecipientStatuses")]
        [XmlArrayItem("RecipientStatus")]
        public List<ConnectRecipient> Recipients { get; set; }

        [XmlElement("EnvelopeID")]
        public Guid ID { get; set; }

        [XmlElement("Email")]
        public string UserID { get; set; }

        [XmlElement("Status")]
        public EnvelopeStatus Status { get; set; }

        [XmlElement("Subject")]
        public string Subject { get; set; }

        [XmlElement("Created")]
        public DateTime CreatedOn { get; set; }

        [XmlElement("Sent")]
        public DateTime SentOn { get; set; }

        [XmlElement("Delivered")]
        public DateTime DeliveredOn { get; set; }

        [XmlElement("Signed")]
        public DateTime SignedOn { get; set; }

        [XmlElement("Completed")]
        public DateTime CompletedOn { get; set; }

        [XmlArray("CustomFields")]
        [XmlArrayItem("CustomField")]
        public List<ConnectCustomField> CustomFields { get; set; }
    }
}
