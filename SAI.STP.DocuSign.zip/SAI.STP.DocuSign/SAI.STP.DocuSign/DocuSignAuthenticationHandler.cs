﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocuSign.eSign.Api;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using System.Web;
using System.Net;
using System.IO;
using Newtonsoft.Json;

namespace SAI.STP.DocuSignIntegration
{
    public class DocuSignAuthenticationHandler
    {
        private string _baseUrl;
        private ICredentials _credentials;

        public DocuSignAuthenticationHandler(string base_url, ICredentials credentials)
        {
            _credentials = credentials;
            _baseUrl = base_url;
        }

        public IAuthenticationTokenResponse GetToken()
        {
            //do login first
            ApiClient apiClient = Configuration.Default.ApiClient;
            string authHeader = "{\"Username\":\"" + _credentials.LoginID + "\", \"Password\":\"" + _credentials.LoginPassword + "\", \"IntegratorKey\":\"" + _credentials.Key + "\"}";
            Configuration.Default.AddDefaultHeader("X-DocuSign-Authentication", authHeader);
            AuthenticationApi authApi = new AuthenticationApi();
            LoginInformation loginInfo = authApi.Login();
            string accountId = null;
            string baseURL = null;
            foreach (LoginAccount loginAcct in loginInfo.LoginAccounts)
            {
                if (loginAcct.IsDefault == "true")
                {
                    accountId = loginAcct.AccountId;
                    baseURL = loginAcct.BaseUrl;

                    break;
                }
            }
            if (accountId == null)
            { // if no default found set to first account
                accountId = loginInfo.LoginAccounts[0].AccountId;
                baseURL = loginInfo.LoginAccounts[0].BaseUrl;
            }

            //get token
            WebRequest request = WebRequest.Create(_baseUrl + "/oauth2/token");
            request.ContentType = "application/x-www-form-urlencoded";
            request.Method = "POST";
            string body = String.Format("grant_type=password&client_id={0}&username={1}&password={2}&scope=api", _credentials.Key, _credentials.LoginID, _credentials.LoginPassword);
            byte[] byteArray = Encoding.UTF8.GetBytes(body);
            request.ContentLength = byteArray.Length;
            Stream dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    AuthenticationTokenResponse tokenResponse = new JsonSerializer().Deserialize<AuthenticationTokenResponse>(new JsonTextReader(new StreamReader(response.GetResponseStream())));
                    tokenResponse.BaseURL = baseURL;
                    tokenResponse.AccountID = accountId;
                    return tokenResponse;
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
                throw (ex);
            }
        }

        public bool RevokeToken(string token)
        {
            WebRequest request = WebRequest.Create(_baseUrl + "/oauth2/revoke");
            request.ContentType = "application/x-www-form-urlencoded";
            request.Method = "POST";
            string body = "token="+token;
            byte[] byteArray = Encoding.UTF8.GetBytes(body);
            request.ContentLength = byteArray.Length;
            Stream dataStream = request.GetRequestStream();
            dataStream.Write(byteArray, 0, byteArray.Length);
            dataStream.Close();
            using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
            {
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    return true;
                }
                return false;
            }            
        }
    }
}
