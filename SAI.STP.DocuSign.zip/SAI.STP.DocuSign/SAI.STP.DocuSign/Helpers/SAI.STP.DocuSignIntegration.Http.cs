﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Newtonsoft.Json;
using System.Configuration;

namespace SAI.STP.DocuSignIntegration
{
    public class Http
    {
        //private static Dictionary<string, string> ErrorTracker = new Dictionary<string, string>();
        private static WebRequest CreateRequest(IDictionary<string, string> headers, string url, string verb, string contentType, TimeSpan timeout)
        {
            url = url.Replace("//", "/").Replace(":/", "://");
            WebRequest request = WebRequest.Create(url);
            if(headers != null)
            {
                foreach (var h in headers)
                {
                    request.Headers[h.Key] = h.Value;
                }
            }
            request.ContentType = contentType;
            request.Method = verb.Trim().ToUpper();
            request.Timeout = (int)timeout.TotalMilliseconds;
            return request;
        }

        public static T Get<T>(string url, IDictionary<string, string> headers, RequestOptions options = null)
        {
            options = options ?? new RequestOptions();
            WebRequest request = CreateRequest(headers, url, "GET", options.ContentType, options.Timeout);

            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        return default(T);
                    }

                    return new JsonSerializer().Deserialize<T>(new JsonTextReader(new StreamReader(response.GetResponseStream())));
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
              //  ErrorTracker[token] = ex.Message;
                if (options.DefaultReturnOnError)
                {
                    return default(T);
                }
                else if (statusCode == 404 && options.DefaultReturnOn404)
                {
                    return default(T);
                }

                throw (ex);
            }

        }

        public static T Post<T>(string url, object data, IDictionary<string, string> headers, RequestOptions options = null)
        {
            options = options ?? new RequestOptions();
            WebRequest request = CreateRequest(headers, url, "POST", options.ContentType, options.Timeout);
            using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                streamWriter.Write(JsonConvert.SerializeObject(data));
            }

            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        return default(T);
                    }

                    return new JsonSerializer().Deserialize<T>(new JsonTextReader(new StreamReader(response.GetResponseStream())));
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
            //    ErrorTracker[token] = ex.Message;
                if (options.DefaultReturnOnError)
                {
                    return default(T);
                }
                else if (statusCode == 404 && options.DefaultReturnOn404)
                {
                    return default(T);
                }

                throw (ex);
            }
        }

        public static bool Post(string url, object data, IDictionary<string, string> headers, RequestOptions options = null)
        {
            options = options ?? new RequestOptions();
            WebRequest request = CreateRequest(headers,url, "POST", options.ContentType, options.Timeout);
            using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                streamWriter.Write(JsonConvert.SerializeObject(data));
            }

            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    return response.StatusCode == HttpStatusCode.OK;
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
            //    ErrorTracker[token] = ex.Message;
                if (options.DefaultReturnOnError)
                {
                    return false;
                }
                else if (statusCode == 404 && options.DefaultReturnOn404)
                {
                    return false;
                }

                throw (ex);
            }
        }

        public static bool Put(string url, object data, IDictionary<string, string> headers, RequestOptions options = null)
        {
            options = options ?? new RequestOptions();
            WebRequest request = CreateRequest(headers, url, "PUT", options.ContentType, options.Timeout);

            using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                streamWriter.Write(JsonConvert.SerializeObject(data));
            }

            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    return response.StatusCode == HttpStatusCode.OK;
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
       //         ErrorTracker[token] = ex.Message;
                if (options.DefaultReturnOnError)
                {
                    return false;
                }
                else if (statusCode == 404 && options.DefaultReturnOn404)
                {
                    return false;
                }

                throw (ex);
            }
        }

        public static T Put<T>(string url, object data, IDictionary<string, string> headers, RequestOptions options = null)
        {
            options = options ?? new RequestOptions();
            WebRequest request = CreateRequest(headers, url, "PUT", options.ContentType, options.Timeout);

            using (var streamWriter = new StreamWriter(request.GetRequestStream()))
            {
                streamWriter.Write(JsonConvert.SerializeObject(data));
            }

            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    if (response.StatusCode != HttpStatusCode.OK)
                    {
                        return default(T);
                    }

                    return new JsonSerializer().Deserialize<T>(new JsonTextReader(new StreamReader(response.GetResponseStream())));
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
             //   ErrorTracker[token] = ex.Message;
                if (options.DefaultReturnOnError)
                {
                    return default(T);
                }
                else if (statusCode == 404 && options.DefaultReturnOn404)
                {
                    return default(T);
                }

                throw (ex);
            }
        }

        public static bool Delete(string url, IDictionary<string, string> headers, RequestOptions options = null)
        {
            options = options ?? new RequestOptions();
            WebRequest request = CreateRequest(headers, url, "DELETE", options.ContentType, options.Timeout);
            try
            {
                using (HttpWebResponse response = request.GetResponse() as HttpWebResponse)
                {
                    return response.StatusCode == HttpStatusCode.OK;
                }
            }
            catch (Exception ex)
            {
                int statusCode = ex is HttpException ? ((HttpException)ex).GetHttpCode() : 0;
          //      ErrorTracker[token] = ex.Message;
                if (options.DefaultReturnOnError)
                {
                    return false;
                }
                else if (statusCode == 404 && options.DefaultReturnOn404)
                {
                    return false;
                }

                throw (ex);
            }
        }

        //public static string GetLastError(string tokenUsed)
        //{
        //    if (ErrorTracker.ContainsKey(tokenUsed))
        //    {
        //        return ErrorTracker[tokenUsed];
        //    }

        //    return null;
        //}
    }

    public class RequestOptions
    {
        public RequestOptions()
        {
            Timeout = new TimeSpan(0, 5, 0);
            ContentType = "application/json";
            DefaultReturnOn404 = true;
            DefaultReturnOnError = true;
        }

        public bool DefaultReturnOn404 { get; set; }
        public bool DefaultReturnOnError { get; set; }
        public TimeSpan Timeout { get; set; }
        public string ContentType { get; set; }
    }
}