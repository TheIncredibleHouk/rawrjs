﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DocuSign.eSign.Client;
using DocuSign.eSign.Model;
using DocuSign.eSign.Api;
using System.IO;
using System.Xml.Serialization;

namespace SAI.STP.DocuSignIntegration
{
    public class DocuSignEnvelopeHandler
    {
        private string _accessToken;
        private string _accountID;

        public DocuSignEnvelopeHandler(IOAuthCredentials credentials)
        {
            _accessToken = credentials.AccessToken;
            _accountID = credentials.AccountID;

            Configuration.Default.AccessToken = _accessToken;
            Configuration.Default.AddDefaultHeader("Authorization", "bearer " + _accessToken);
            ApiClient apiClient = new ApiClient("https://na2.docusign.net/restapi");
            Configuration.Default.ApiClient = apiClient;

        }

        public IEnvelopeCondition CreateEnvelope(IEnvelopeCustomFields customFields, IEnvelopeStart envelopeStart)
        {
            EnvelopeDefinition envDef = new EnvelopeDefinition();
            envDef.EmailSubject = envelopeStart.EmailSubject;
            envDef.EmailBlurb = envelopeStart.EmailBody;

            foreach(var document in envelopeStart.Documents)
            {
                Document doc = new Document();
                doc.DocumentBase64 = Convert.ToBase64String(document.Data);
                doc.DocumentId = document.ID;
                doc.Order = document.Order.ToString();
                doc.Name = document.Name;
                //mime type- was ignored
                envDef.Documents = new List<Document>();
                envDef.Documents.Add(doc);
            }
            envDef.Recipients = new Recipients();
            envDef.Recipients.CarbonCopies = new List<CarbonCopy>();
            foreach(var c in envelopeStart.Recipients.CarbonCopies)
            {
                CarbonCopy copy = new CarbonCopy();
                copy.AccessCode = c.AccessCode;
                copy.DeclinedReason = c.DeclineReason;
                copy.DeliveredDateTime = c.DeliveredOn.ToString();
                copy.Email = c.Email;
                copy.RecipientId = c.ID;
                copy.IdCheckConfigurationName = c.IDCheckConfigurationName;
                copy.InheritEmailNotificationConfiguration = c.InheritEmailNotificationConfiguration.ToString();
                copy.Name = c.Name;
                copy.RequireIdLookup = c.RequireIDLookup.ToString();
                copy.RoleName = c.RoleName;
                copy.RoutingOrder = c.RoutingOrder.ToString();
                copy.SignedDateTime = c.SignedOn.ToString();
                copy.Status = c.Status.ToString();
                envDef.Recipients.CarbonCopies.Add(copy);
            }
            
            envDef.Recipients.RecipientCount = envelopeStart.Recipients.Count.ToString();
            envDef.Recipients.Signers = new List<Signer>();
            foreach(var s in envelopeStart.Recipients.Signers)
            {
                var signer = new Signer();
                RecipientSignatureInformation sigInfo = new RecipientSignatureInformation();
                sigInfo.SignatureName = s.SignatureInfo.Name;
                sigInfo.SignatureInitials = s.SignatureInfo.Initials;
                sigInfo.FontStyle = s.SignatureInfo.FontStyle.ToString();
                signer.SignatureInfo = sigInfo;
                signer.RecipientId = s.ID;
                signer.Email = s.Email;
                signer.Name = s.Name;
                signer.AccessCode = s.AccessCode;
                signer.InheritEmailNotificationConfiguration = s.InheritEmailNotificationConfiguration.ToString();
                signer.RoutingOrder = s.RoutingOrder.ToString();
                signer.Status = s.Status.ToString();
                
                signer.Tabs = new Tabs();
                signer.Tabs.SignHereTabs = new List<SignHere>();
                if (s.Tabs.SignHereTabs != null)
                {
                    foreach (var t in s.Tabs.SignHereTabs)
                    {
                        SignHere signHere = new SignHere();
                        signHere.DocumentId = t.DocumentID;
                        signHere.PageNumber = t.PageNumber;
                        signHere.RecipientId = t.RecipientID;
                        signHere.XPosition = t.XPosition;
                        signHere.YPosition = t.YPosition;
                        signer.Tabs.SignHereTabs.Add(signHere);
                    }
                }
                signer.Tabs.InitialHereTabs = new List<InitialHere>();
                if (s.Tabs.InitialHereTabs != null)
                {
                    foreach (var t in s.Tabs.InitialHereTabs)
                    {
                        InitialHere initialHere = new InitialHere();
                        initialHere.DocumentId = t.DocumentID;
                        initialHere.PageNumber = t.PageNumber;
                        initialHere.RecipientId = t.RecipientID;
                        initialHere.XPosition = t.XPosition;
                        initialHere.YPosition = t.YPosition;
                        signer.Tabs.InitialHereTabs.Add(initialHere);
                    }
                }
                signer.Tabs.DateSignedTabs = new List<DateSigned>();
                if (s.Tabs.DateSignedTabs != null)
                {
                    foreach (var t in s.Tabs.DateSignedTabs)
                    {
                        DateSigned dateSigned = new DateSigned();
                        dateSigned.DocumentId = t.DocumentID;
                        dateSigned.PageNumber = t.PageNumber;
                        dateSigned.RecipientId = t.RecipientID;
                        dateSigned.XPosition = t.XPosition;
                        dateSigned.YPosition = t.YPosition;
                        signer.Tabs.DateSignedTabs.Add(dateSigned);
                    }
                }
                envDef.Recipients.Signers.Add(signer);
            }
            //custom fields
            CustomFields cfs = new CustomFields();
            List<TextCustomField> textCustomFields = new List<TextCustomField>();
            foreach(var c in customFields.CustomFields)
            {
                TextCustomField customField = new TextCustomField();
                customField.Name = c.Key;
                customField.Value = c.Value;
                textCustomFields.Add(customField);
            }
            cfs.TextCustomFields = textCustomFields;
            envDef.CustomFields = cfs;
           
            //set status to sent to send sig request immediately
            envDef.Status = "sent";

            EnvelopesApi envelopeApi = new EnvelopesApi();
            EnvelopeSummary envSummary = envelopeApi.CreateEnvelope(_accountID, envDef);
            EnvelopeCondition envStatus = new EnvelopeCondition();
            envStatus.Date = envSummary.StatusDateTime;
            envStatus.ID = envSummary.EnvelopeId;
            envStatus.Status = envSummary.Status;
            envStatus.Uri = envSummary.Uri;
            return envStatus;
            
        }


        public EnvelopeUpdateSummary ResendEnvelope(string envelopeId)
        {
            EnvelopesApi envelopeApi = new EnvelopesApi();
            Envelope envelope = new Envelope();
            EnvelopesApi.UpdateOptions options = new EnvelopesApi.UpdateOptions();
            options.resendEnvelope = "true";
            EnvelopeUpdateSummary response = envelopeApi.Update(_accountID, envelopeId, envelope, options);
            return response;
        }

        public EnvelopeUpdateSummary VoidEnvelope(string envelopeId, string reason)
        {
            EnvelopesApi envelopeApi = new EnvelopesApi();
            Envelope envelope = new Envelope();
            envelope.Status = "voided";
            envelope.VoidedReason = "void reason";
            EnvelopeUpdateSummary response =  envelopeApi.Update(_accountID, envelopeId, envelope);
            return response;
        }

        public Envelope GetEnvelope(string envelopeId)
        {
            EnvelopesApi envelopeApi = new EnvelopesApi();
            Envelope envelope = envelopeApi.GetEnvelope(_accountID, envelopeId);
            return envelope;
        }

        public List<byte[]> GetDocument(string envelopeId)
        {
            EnvelopesApi envelopesApi = new EnvelopesApi();
            EnvelopeDocumentsResult docsList = envelopesApi.ListDocuments(_accountID, envelopeId);
            int docCount = docsList.EnvelopeDocuments.Count;
            List<byte[]> docBytes = new List<byte[]>();
            // GetDocument() API call returns a MemoryStream
            for (int i = 0; i < docCount; i++)
            {
                if (docsList.EnvelopeDocuments[i].DocumentId != "certificate")
                {
                    using (MemoryStream docStream = (MemoryStream)envelopesApi.GetDocument(_accountID, envelopeId, docsList.EnvelopeDocuments[i].DocumentId))
                    {
                        byte[] pdfBytes = docStream.ToArray();
                        docBytes.Add(pdfBytes);
                    }
                }
            }
            return docBytes;
        }

        //--------------------------------------

        public ConnectEnvelopeInformation HandleCallbackRequest(string request)
        {
            ConnectEnvelopeInformation info = null;
            var xs = new XmlSerializer(typeof(ConnectEnvelopeInformation));
            using (var sr = new StringReader(request))
            {
                info = (ConnectEnvelopeInformation)xs.Deserialize(sr);
                if (info == null)
                {
                    return null;
                }
            }
            return info;
        }
    }
}