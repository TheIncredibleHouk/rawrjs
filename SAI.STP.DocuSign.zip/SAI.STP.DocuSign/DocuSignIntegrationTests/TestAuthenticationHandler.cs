﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SAI.STP.DocuSignIntegration;

namespace DocuSignTests
{
    [TestClass]
    public class TestAuthenticationHandler
    {
        public class Credentials: ICredentials
        {
            public string Key { get; set; }
            public string LoginID { get; set; }
            public string LoginPassword { get; set; }
            public string SendOnBehalf { get; set; }
        }

        [TestMethod]
        public void TestGetToken()
        {
            DocuSignAuthenticationHandler authHandler = new DocuSignAuthenticationHandler("https://na2.docusign.net/restapi/v2", new Credentials() { Key = "SSNX-b2c92fb0-6829-4561-8662-a60d791bc0ef", LoginID = "alphafeedback@ssnetwork.com", LoginPassword = "demopassword" });
            IAuthenticationTokenResponse response = authHandler.GetToken();
            Assert.IsNotNull(response.AccountID);
            Assert.IsNotNull(response.BaseURL);
            Assert.IsNotNull(response.Access_Token);
        }

        [TestMethod]
        public void TestRevokeToken()
        {
            DocuSignAuthenticationHandler authHandler = new DocuSignAuthenticationHandler("https://na2.docusign.net/restapi/v2", new Credentials() { Key = "SSNX-b2c92fb0-6829-4561-8662-a60d791bc0ef", LoginID = "jeff.polakiewicz@ssnetwork.com", LoginPassword = "demopassword" });
            bool response = authHandler.RevokeToken("UaSxccpbRheS+Nqk2VQGBHIsNsI=");
            Assert.IsTrue(response == true);
        }
    }
}
