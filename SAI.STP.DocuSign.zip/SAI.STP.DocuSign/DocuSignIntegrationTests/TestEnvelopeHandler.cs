﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SAI.STP.DocuSignIntegration;
using System.Collections.Generic;
using DocuSign.eSign.Model;

namespace DocuSignIntegrationTests
{
    [TestClass]
    public class TestEnvelopeHandler
    {
        private class OAuthCredentials: IOAuthCredentials
        {
            public string AccessToken { get; set; }
            public string AccountID { get; set; }
        }

        private class EnvelopeCustomFields : IEnvelopeCustomFields
        {
            public IDictionary<string, string> CustomFields { get; set; }
        }

        private class EnvelopeStart: IEnvelopeStart
        {
            public IEnumerable<IDocument> Documents { get; set; }
            public string EmailBody { get; set; }
            public string EmailSubject { get; set; }
            public IRecipientInfo Recipients { get; set; }
            public EnvelopeStatus Status { get; set; }
        }

        [TestMethod]
        public void TestGetEnvelope()
        {
            DocuSignEnvelopeHandler envHandler = new DocuSignEnvelopeHandler(new OAuthCredentials() { AccessToken = "hg2P+f+cMBEWojMVq0UQx+QXKo0=", AccountID = "5788154" });
            string envelopeID = "1779e00b-c647-4ebd-8efc-95979ce68660";
            Envelope response = envHandler.GetEnvelope(envelopeID);
            Assert.IsNotNull(response);
        }

        [TestMethod]
        public void TestGetDocument()
        {
            DocuSignEnvelopeHandler envHandler = new DocuSignEnvelopeHandler(new OAuthCredentials() { AccessToken = "hg2P+f+cMBEWojMVq0UQx+QXKo0=", AccountID = "5788154" });
            string envelopeID = "1779e00b-c647-4ebd-8efc-95979ce68660";
            byte[] bytes = envHandler.GetDocument(envelopeID);
            Assert.IsNotNull(bytes);
        }

        [TestMethod]
        public void TestResendEnvelope()
        {
            DocuSignEnvelopeHandler envHandler = new DocuSignEnvelopeHandler(new OAuthCredentials() { AccessToken = "hg2P+f+cMBEWojMVq0UQx+QXKo0=", AccountID = "5788154" });
            string envelopeID = "1779e00b-c647-4ebd-8efc-95979ce68660";
            var response = envHandler.ResendEnvelope(envelopeID);
            Assert.IsNotNull(response);
        }

        [TestMethod]
        public void TestVoidEnvelope()
        {
            DocuSignEnvelopeHandler envHandler = new DocuSignEnvelopeHandler(new OAuthCredentials() { AccessToken = "hg2P+f+cMBEWojMVq0UQx+QXKo0=", AccountID = "5788154" });
            string envelopeID = "1779e00b-c647-4ebd-8efc-95979ce68660";
            var response = envHandler.VoidEnvelope(envelopeID, "void reason");
            Assert.IsNotNull(response);
            Envelope envelope = envHandler.GetEnvelope(envelopeID);
            Assert.IsTrue(envelope.Status == "voided");
            Assert.IsTrue(envelope.VoidedReason == "void reason");
        }
    }
}
