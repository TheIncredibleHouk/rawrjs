﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class Recipient: IRecipient
    {
        public string AccessCode { get; set; }
        public string DeclineReason { get; set; }
        public DateTime DeliveredOn { get; set; }
        public string Email { get; set; }
        public string ID { get; set; }
        public string IDCheckConfigurationName { get; set; }
        public bool InheritEmailNotificationConfiguration { get; set; }
        public string Name { get; set; }
        public bool RequireIDLookup { get; set; }
        public string RoleName { get; set; }
        public int RoutingOrder { get; set; }
        public DateTime SignedOn { get; set; }
        public EnvelopeStatus Status { get; set; }
    }
}
