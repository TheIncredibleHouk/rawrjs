﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class Signer: Recipient, ISigner
    {
        public ISignatureInfo SignatureInfo { get; set; }
        public ITabCollection Tabs { get; set; }
    }
}
