﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class RecipientInfo: IRecipientInfo
    {
        public IEnumerable<IRecipient> CarbonCopies { get; set; }
        public int Count
        {
            get
            {
                int count = 0;
                if (Signers != null)
                    count += Signers.Count();
                if (CarbonCopies != null)
                    count += CarbonCopies.Count();
                return count;
            }
        }
        public IEnumerable<ISigner> Signers { get; set; }

        public bool Any(Func<IRecipient, bool> predicate)
        {
            throw new NotImplementedException();
        }
        public IRecipient FirstOrDefault(Func<IRecipient, bool> predicate)
        {
            throw new NotImplementedException();
        }
    }
}
