﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class Document : IDocument
    {
        public byte[] Data { get; set; }
        public string ID { get; set; }
        public string MimeType { get; set; }
        public int Order { get; set; }
        public string Name { get; set; }
    }
}
