﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class Tab: ITab
    {
        public string DocumentID { get; set; }
        public string PageNumber { get; set; }
        public string RecipientID { get; set; }
        public string XPosition { get; set; }
        public string YPosition { get; set; }
    }
}
