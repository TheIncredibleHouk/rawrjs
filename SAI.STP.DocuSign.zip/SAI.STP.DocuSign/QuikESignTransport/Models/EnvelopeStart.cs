﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class EnvelopeStart: IEnvelopeStart
    {
        public IEnumerable<IDocument> Documents { get; set; }
        public string EmailBody { get; set; }
        public string EmailSubject { get; set; }
        public IRecipientInfo Recipients { get; set; }
        public EnvelopeStatus Status { get; set; }
    }
}
