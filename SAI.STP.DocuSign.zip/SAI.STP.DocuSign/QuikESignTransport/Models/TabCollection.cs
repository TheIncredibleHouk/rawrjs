﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
    public class TabCollection: ITabCollection
    {
        public IEnumerable<ITab> DateSignedTabs { get; set; }
        public IEnumerable<ITab> InitialHereTabs { get; set; }
        public IEnumerable<ITab> SignHereTabs { get; set; }
    }
}
