﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Collections;
using System.Text;
using System.Xml;
using Newtonsoft.Json;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web.Http;
using SAI.STP.DocuSignIntegration;

namespace QuikESignTransport.Controllers
{
     class OAuthCredentials: IOAuthCredentials
    {
        public string AccessToken { get; set; }
        public string AccountID { get; set; }
        public string IntegratorKey { get; set; }
    }

    public class QuikTransportController : ApiController
    {
        //private ILog logger = log4net.LogManager.GetLogger("QuikSignTransport");

        private String createJSON(String statusCode, String statusMessage)
        {
            //logger.Debug("JSON: " + "{\"StatusCode\":\"" + statusCode + "\",\"StatusMessage\":\"" + statusMessage + "\"}");
            return JsonConvert.SerializeObject(new { StatusCode = statusCode, StatusMessage = statusMessage }).ToString();
        }

        private String FileName()
        {
            String strFileName = DateTime.Now.Ticks.ToString() + ".pdf";
            //logger.Debug("fileName: " + strFileName);
            return strFileName;
        }

        //private String DocuSignTransporter(Byte[] strPath, XmlDocument XMLDataEntryPath)
        //{
        //    //EnvelopeCreatorProject.EnvelopeTransporterCreator objEnvelopeCreator = new EnvelopeCreatorProject.EnvelopeTransporterCreator();
        //    String PDFName = FileName();
        //    String strResult = objEnvelopeCreator.CreateEnvelopeTransporter(strPath, PDFName, XMLDataEntryPath);
        //    return strResult;
        //}

        private static string DropFirstSpace(string str)
        {
            if (str.StartsWith(" "))
            {
                return str.Substring(1, str.Length - 1);
            }
            return str;
        }

        private static string ExtractInitials(string fullName)
        {
            string[] parts = fullName.Split(new char[] { ' ' });
            string ret = "";
            foreach (string part in parts)
            {
                if (part.Length > 1)
                {
                    ret = ret + part[0];
                }
            }
            return ret;
        }

        private static Recipient CreateRecipient(XmlNode m_node)
        {
            string Id = m_node.ChildNodes.Item(0).InnerText;
            string strFullName = m_node.ChildNodes.Item(1).InnerText;
            string strMail = m_node.ChildNodes.Item(2).InnerText;
            string strRountingOrder = m_node.ChildNodes.Item(3).InnerText;
            // this will allow that an envelope can distribute the forms to the same email and with differents roles.
            string strID = Id + strRountingOrder;
            string strSignType = m_node.ChildNodes.Item(4).InnerText;
            string strVerifyCode = m_node.ChildNodes.Item(5).InnerText;

            bool isCarbonCopy = strSignType == "SC";
            Recipient objRecipient = isCarbonCopy ? new Recipient() : new Signer();
            objRecipient.Status = EnvelopeStatus.Created;
            objRecipient.ID = strID;
            objRecipient.RoutingOrder = Convert.ToUInt16(strRountingOrder);;
            objRecipient.Email = strMail;
            objRecipient.Name = strFullName;

            objRecipient.InheritEmailNotificationConfiguration = true;
            objRecipient.AccessCode = strVerifyCode;

            if (!isCarbonCopy)
            {
                Signer signer = (Signer)objRecipient;
                SignatureInfo sigInfo = new SignatureInfo();
                sigInfo.FontStyle = FontStyle.Mistral;
                sigInfo.Name = objRecipient.Name;
                sigInfo.Initials = ExtractInitials(objRecipient.Email);
                signer.SignatureInfo = sigInfo;
            }

            return objRecipient;
        }

        public static IEnvelopeStart CreateEnvelope(byte[] pdfBytes, string strFileName, XmlDocument m_xmld)
        {
            RecipientInfo recipients = new RecipientInfo();

            List<Document> documents = new List<Document>();
            Document doc = new Document();
            doc.Data = pdfBytes;
            doc.Name = strFileName;
            doc.ID = "1";
            documents.Add(doc);

            string mailSubject = DropFirstSpace(m_xmld.SelectNodes("/recipients/mailData/mailSubject")[0].InnerText);
            string mailBody = DropFirstSpace(m_xmld.SelectNodes("/recipients/mailData/mailBody")[0].InnerText);

            //add ssn disclosure
            //string ssn_disclosure = ConfigurationManager.AppSettings["esign_disclosure"] ?? "Securities offered through Securities Service Network, Inc., Member FINRA/SIPC";

           // if (!mailBody.Contains(ssn_disclosure))
          //  {
                //mailBody += Environment.NewLine + Environment.NewLine + ssn_disclosure;
          //  }

            XmlNodeList m_nodelist;
            m_nodelist = m_xmld.SelectNodes("/recipients/recipient");

            List<Signer> signers = new List<Signer>();
            List<Recipient> objRecipients = new List<Recipient>();

            foreach (XmlNode m_node in m_nodelist)
            {
                Recipient objRecipient;
                string RecipientID = m_node.ChildNodes.Item(0).InnerText;
                string checkId = m_node.ChildNodes.Item(6).InnerText;

                if (recipients.Count == 0 || !recipients.Any(r => r.ID == RecipientID))
                {
                    objRecipient = CreateRecipient(m_node);
                    if (checkId.Equals("true"))
                    {
                        objRecipient.RequireIDLookup = true;
                        objRecipient.IDCheckConfigurationName = "ID Check $";
                    }

                    Signer signer = objRecipient as Signer;
                    if (signer != null)
                    {
                        signers.Add(signer);
                    }
                    else
                    {
                        objRecipients.Add(objRecipient);
                    }
                        
                }
                else
                {
                    String ID = m_node.ChildNodes.Item(0).InnerText + m_node.ChildNodes.Item(3).InnerText;
                    objRecipient = (Recipient)recipients.FirstOrDefault(r => r.ID == RecipientID);
                    if (objRecipient == null)
                    {
                        objRecipient = CreateRecipient(m_node);
                        Signer signer = objRecipient as Signer;
                        if (signer != null)
                        {
                            signers.Add(signer);
                        }
                           
                        else
                        {
                            objRecipients.Add(objRecipient);
                        }
                            
                    }
                }

                foreach (XmlNode m_node2 in m_node.ChildNodes[7])
                {
                    string strPageNumber = m_node2.ChildNodes.Item(0).InnerText;
                    string strXCoor = m_node2.ChildNodes.Item(1).InnerText;
                    string strYCoor = m_node2.ChildNodes.Item(2).InnerText;
                    string strDateXCoor = m_node2.ChildNodes.Item(3).InnerText;
                    string strDateYCoor = m_node2.ChildNodes.Item(4).InnerText;
                    string strsSignInitials = m_node2.ChildNodes.Item(5).InnerText;

                    // Creating the Signatures Tabs
                    Tab objTab = new Tab();

                    objTab.RecipientID = objRecipient.ID;
                    objTab.PageNumber = strPageNumber;
                    objTab.XPosition = strXCoor;
                    objTab.YPosition = strYCoor;
                    objTab.DocumentID = doc.ID;

                    Signer signer = objRecipient as Signer;
                    if (signer != null)
                    {
                        List<Tab> objTabs = new List<Tab>();
                        objTabs.Add(objTab);
                        if (strsSignInitials == "1")
                        {
                            TabCollection tabs = new TabCollection();
                            tabs.InitialHereTabs = objTabs;
                            signer.Tabs = tabs;
                        }
                        else
                        {
                            TabCollection tabs = new TabCollection();
                            tabs.SignHereTabs = objTabs;
                            signer.Tabs = tabs;
                        }

                        //If the DateXCoord is 0 => There isn't a date sign for this sign field
                        if (strDateXCoor != "0")
                        {
                             List<Tab> dateTabs = new List<Tab>();
                            objTab = new Tab();
                            objTab.RecipientID = objRecipient.ID;
                            objTab.PageNumber = strPageNumber;
                            objTab.XPosition = strDateXCoor;
                            objTab.YPosition = strDateYCoor;
                            objTab.DocumentID = doc.ID;

                            dateTabs.Add(objTab);

                            signer.Tabs.DateSignedTabs = dateTabs;
                        }
                    }
                }
            }

            recipients.Signers = signers;
            recipients.CarbonCopies = objRecipients;


            EnvelopeStart envelope = new EnvelopeStart();

            envelope.Status = EnvelopeStatus.Sent;
            envelope.EmailSubject = mailSubject;
            envelope.EmailBody = mailBody;
            envelope.Recipients = recipients;
            envelope.Documents = documents;

            return envelope;
        }


        [Route("quiktransport")]
        public object HandleQuikRequest([FromBody] object request, [FromUri] string bundleID)
        {
            string requestBody = request.ToString();

            try
            {

                string[] StringArray = requestBody.Split(new string[] { "&BeginSign&" }, System.StringSplitOptions.None);
                string strFormFieldsData = StringArray[0];
                string strFormSignData = StringArray[1];


                string[] StringDataSign = strFormSignData.Split(new string[] { "&EndSign&" }, System.StringSplitOptions.None);
                string strRecipientData = StringDataSign[0];
                string strSignFieldData = StringDataSign[1];

                //Call the Quik! server to get the Docusign data (XML)
                DocuSignData.GetDocusignData wsGetDocusignData = new DocuSignData.GetDocusignData();
                DocuSignData.QuikResultWS result = wsGetDocusignData.GetDocusignResources(strFormFieldsData, strRecipientData, strSignFieldData);

                if (result.ErrorCode.ToString().Equals("0"))
                {
                    Byte[] pdfBytes = Convert.FromBase64String(result.ResultData.Tables[0].Rows[0][0].ToString());

                    string XML = result.ResultData.Tables[0].Rows[0][1].ToString();
                    XmlDocument XmlDoc = new XmlDocument();
                    XmlDoc.LoadXml(HttpUtility.UrlDecode(XML));

                    IEnvelopeStart envelopeStart = CreateEnvelope(pdfBytes, DateTime.Now.Ticks.ToString() + ".pdf", XmlDoc);

                    //custom fields
                    Dictionary<string, string> customField = new Dictionary<string,string>();
                    customField.Add("Bundle ID", bundleID);
                    EnvelopeCustomFields customFields = new EnvelopeCustomFields();
                    customFields.CustomFields = customField;

                    //docusign create envelope

                    //hard coded credentials until we figure out what do
                    OAuthCredentials credentials = new OAuthCredentials();
                    credentials.AccessToken = "sKGKW199Fm8R4qXauWwO1ze1PBY=";
                    credentials.AccountID = "5788154";

                    DocuSignEnvelopeHandler envHandler = new DocuSignEnvelopeHandler(credentials);
                    IEnvelopeCondition envelope = envHandler.CreateEnvelope(customFields, envelopeStart);

                }
                return JsonConvert.SerializeObject(new { StatusCode = result.ErrorCode.ToString(), StatusMessage = result.Message });

            }
            catch (Exception ex)
            {
                //logger.Error("Response from QuikSignTransportFailed. Reason: " + ex.Message + ". " + ex.StackTrace.ToString());

                string strSupportEmail = System.Configuration.ConfigurationManager.AppSettings["SupportEmail"];
                string strSupportPhone = System.Configuration.ConfigurationManager.AppSettings["SupportPhone"];
                string strErrorCode = "1111";

                //Customize your error response here
                return JsonConvert.SerializeObject(new { StatusCode = strErrorCode, StatusMessage = "MESSAGE:\nPlease print your document and contact the administrator at " + strSupportEmail + " or " + strSupportPhone + ". \n\nDETAILS:\n" + ex.Message });
                //String json = this.createJSON(strErrorCode, "MESSAGE:\nPlease print your document and contact the administrator at " + strSupportEmail + " or " + strSupportPhone + ". \n\nDETAILS:\n" + ex.Message);
            }
        }
    }
}
